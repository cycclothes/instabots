# Instabot Documentation

Welcome to [Instabot](https://github.com/instagrambot/) Documentation! 

Available languages: [🇬🇧](en/README.md) [🇷🇺](ru/README.md) [🇮🇹](it/README.md) [🇺🇦](ukr/README.md) [🇪🇸](es/README.md) [🇰🇷](kr/README.md)



## Contributing

If you want to fix or add some new docs, please follow the [guideline](https://github.com/instagrambot/docs/blob/master/CONTRIBUTING.md).

___
[*source*](https://github.com/instagrambot/docs/)
